package edu.boun.edgecloudsim.task_generator;

import java.util.*;

public class vaishnav {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<int[]> data=new ArrayList<int[]>();
		data.add(new int[]{1,0,3,7,1,3});
		data.add(new int[]{2,2,2,5,1,2});
		data.add(new int[]{3,4,1,5,2,2});
		
		int res_had=-1;
		int res_lock=1;
		int ckt=1;
		int completed=0;
		
		
		
		
	    PriorityQueue<int[]> blocked=new PriorityQueue<int[]>(new Comparator<int[]>() {

			@Override
			public int compare(int[] o1, int[] o2) {
				// TODO Auto-generated method stub

			    if(o1[2]==o2[2])return o2[7]-o1[7];
			    return o1[2]-o2[2];
			}
	    	
	    });
	    
	    PriorityQueue<int[]> process=new PriorityQueue<int[]>(new Comparator<int[]>() {

			@Override
			public int compare(int[] o1, int[] o2) {
				// TODO Auto-generated method stub
				
				
			    if(o1[2]==o2[2])return o2[7]-o1[7];
			    return o1[2]-o2[2];
			    
			    
			}
	    	
	    });
	    
	   for(int[] ele:process) {
		   System.out.println(Arrays.toString(ele));
	   }
	    
	    ArrayList<int[]> ds=new ArrayList<>();
	    for(int[] ele:data) {
			ele[3]=ele[1]+ele[3];
			ele[4]=ele[4]+ele[1];
			ele[5]=ele[5]+ele[4];
			System.out.println(Arrays.toString(ele));
			ds.add(ele);
		}
	    
	    ArrayList<ArrayList<int[]>> table=new ArrayList<>();
	    HashMap<Integer,int[]> hs=new HashMap<>();
	    
	    
	    int total=0;
	    int max=0;
	    for(int [] ele:ds) {
	    	
	    	int[] tem=new int[8];
	    	tem[0]=ele[0];
	    	tem[1]=ele[1];
	    	tem[2]=ele[2];
	    	tem[3]=ele[4]-ele[1];
	    	tem[4]=ele[5]-ele[4];
	    	tem[5]=ele[3]-ele[5];
	    	tem[6]=3;
	    	hs.put(tem[1],tem);
	    	total+=(tem[3]+tem[4]+tem[5]);
	    	max=Math.max(tem[1], max);
	    	System.out.println(Arrays.toString(tem));
	    }
		total+=max;
	    int[] curr=null;
	    for(int i=0;i<=total;i++) {
	    	
	    	if(hs.containsKey(i))process.add(hs.get(i));
	    	
	    	if(process.size()!=0) {
	    		if(curr==null)curr=process.peek();
	    		
	    		//priority
	    		if(Arrays.equals(curr, process.peek())){
	    			
	    		while(curr[6]<=6 && curr[curr[6]]==0)curr[6]++;
	    		
	    		if(curr[6]==7) {
	    			process.poll();
	    			curr=null;
	    			continue;
	    		}
                int index=curr[6];
	    			
	    			if(index!=4) {
	    				curr[index]--;
	    				System.out.println("Process:"+curr[0]+"  "+"Time: ["+i+":"+(i+1)+"]");
	    				System.out.println("");
	    				System.out.println("");
	    			}if(index==4 && res_had==-1) {
	    		        
		    			if(curr[index]!=0) {
		    				curr[index]--;
		    				System.out.println("Process:"+curr[0]+"  "+"Time: ["+i+":"+(i+1)+"]");
		    				System.out.println("");
		    				System.out.println("");
		    			}
		    			
		    			if(index==4 && curr[index]!=0) {
		    				res_had=curr[0];
		    			}else if(index==5 && curr[index]==0) {
		    				curr=null;
		    				process.poll();
		    			}else if(curr[index]==0)curr[6]++;
	    			}else if(index==4) {
		    			
		    			Stack<int[]> stk1=new Stack<>();
		    			int[] hold=null;
		    			while(!blocked.isEmpty() && blocked.peek()[0]!=res_had)stk1.add(blocked.poll());
		    			hold=blocked.poll();
		    			while(!stk1.isEmpty())process.add(stk1.pop());
		    			
		    			if(hold!=null) {
		    			hold[7]=ckt++;
		    			hold[2]=curr[2];
		    			
		    			process.add(hold);
		    			i--;
		    			res_had=-1;
		    			System.out.println("**************SHIFTING PRIORITY OF PROCESS "+curr[0]+"  to  PROCESS "+hold[0]+"  ****** RESOURCE CONTRADICT");
		    			System.out.println("");
	    				System.out.println("");
	    				System.out.println("--------------------------------");
		    		
		    			}else {
		    				if(curr[index]!=0) {
		    					curr[index]--;
		    				}
		    				if(curr[index]==0)curr[6]++;
		    				
		    				System.out.println("Process:"+curr[0]+"  "+"Time: ["+i+":"+(i+1)+"]");
		    				System.out.println("");
		    				System.out.println("");
		    				System.out.println("--------------------------------");
		    			}
		    			
		    			continue;
	    				
	    			}
	    			
	    		    if(index<5 && curr[index]==0)curr[6]++;
	    			
	    			if(index==5 && curr[index]==0) {
	    				curr=null;
	    				process.poll();
	    			}
	    			
	    		
	    			
	    			
	    		}else {
	    			
	    			blocked.add(curr);
	    			int id=curr[0];
	    			
	    			Stack<int[]> stk=new Stack<>();
	    			while(!process.isEmpty() && process.peek()[0]!=id)stk.add(process.poll());
	    			process.poll();
	    			while(!stk.isEmpty())process.add(stk.pop());
	    			
	    			
	    			curr=process.peek();
	    			
	    			int index=curr[6];
	    			
	    			if(index!=4) {
	    				curr[index]--;
	    				System.out.println("Process:"+curr[0]+"  "+"Time: ["+i+":"+(i+1)+"]");
	    				System.out.println("");
	    				System.out.println("");
	    			}if(index==4 && res_had==-1) {
		    			if(curr[index]!=0) {
		    				curr[index]--;
		    			}
		    			
		    			if(index==4 && curr[index]!=0) {
		    				res_had=curr[0];
		    			}else if(index==5 && curr[index]==0) {
		    				curr=null;
		    				process.poll();
		    			}else if(curr[index]==0)curr[6]++;
		    			System.out.println("Process:"+curr[0]+"  "+"Time: ["+i+":"+(i+1)+"]");
		    			System.out.println("");
	    				System.out.println("");
	    				
		    			
	    			}else if(index==4) {
		    			
	    				Stack<int[]> stk1=new Stack<>();
		    			int[] hold=null;
		    			while(!blocked.isEmpty() && blocked.peek()[0]!=res_had)stk1.add(blocked.poll());
		    			hold=blocked.poll();
		    			while(!stk1.isEmpty())process.add(stk1.pop());
		    			
		    			if(hold!=null) {
		    			hold[7]=ckt++;
		    			hold[2]=curr[2];
		    			System.out.println("**************SHIFTING PRIORITY OF PROCESS "+curr[0]+"  to  PROCESS "+hold[0]+"  ****** RESOURCE CONTRADICT");
		    			System.out.println("");
	    				System.out.println("");
	    				System.out.println("--------------------------------");
		    			process.add(hold);
		    			i--;
		    			res_had=-1;
		    		
		    			}else {
		    				if(curr[index]!=0) {
		    					curr[index]--;
		    				}
		    				if(curr[index]==0)curr[6]++;
		    				
		    				System.out.println("Process:"+curr[0]+"  "+"Time: ["+i+":"+(i+1)+"]");
		    				System.out.println("");
		    				System.out.println("");
		    				System.out.println("--------------------------------");
		    			}
		    			
		    			continue;
	    				
	    			}
	    			
	    			if(index<5 && curr[index]==0)curr[6]++;
	    			 
	    			if(index==5 && curr[index]==0) {
	    				curr=null;
	    				process.poll();
	    			}
	    			
	    			
	    		}
	    		
	    		
	    		
	    	}else if(blocked.size()!=0) {
	    		
	    		
	    	    res_had=-1;
	    	   
	    	    while(blocked.size()!=0)process.add(blocked.poll());
	    		
	    		
	    		
	    		
	    	}
	    	
	    	
	    	System.out.println("--------------------------------");
	    }

	}

}
